package com.example.demo;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class BookStoreController 
{
@Autowired
private BookService bookservice;
@GetMapping("/bookstore/books")
public List<Book> getAllBook()
{
	List<Book> allBookList=bookservice.getAllBook();
	return allBookList;
}

@GetMapping("/bookstore/books/{bookid}")
public Book getBookById(@PathVariable String bookid)
{
	Book bookDetails=bookservice.getBookById(Integer.parseInt(bookid));
	return bookDetails;
	}
@RequestMapping(method=RequestMethod.POST, value="/bookstore/books")
public void addBook(@RequestBody Book book)
{
	bookservice.addBook(book);
}

@RequestMapping(method=RequestMethod.PUT, value="/bookstore/books/{bookid}")
public void editBook(@RequestBody Book book,@PathVariable String bookid)
{
	bookservice.editBook(book,Integer.parseInt(bookid));
}

@RequestMapping(method=RequestMethod.DELETE, value="/bookstore/books/{bookid}")
public void deleteBook(@PathVariable String bookid)
{
	bookservice.deleteBook(Integer.parseInt(bookid));
}

}
