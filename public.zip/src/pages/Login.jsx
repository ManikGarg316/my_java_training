import '../styles/Login.css'
const Login = () => {
    return (
        <>
            <div className="color-green"></div>
            <div className='color-yellow'></div>
            <div className='color-brown'></div>
        </>
    )
};
export default Login;