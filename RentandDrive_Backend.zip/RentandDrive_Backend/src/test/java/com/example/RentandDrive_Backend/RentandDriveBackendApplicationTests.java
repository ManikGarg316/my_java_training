package com.example.RentandDrive_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentandDriveBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
