package com.example.RentandDrive_Backend.service;
import com.example.RentandDrive_Backend.entity.CarDetails;
import java.util.List;

public interface CarDetailsService {
     public List<CarDetails> getCarDetails(long id);
     public CarDetails addCarDetails(CarDetails car);
     public CarDetails deleteCarDetails(long id);
     public CarDetails updateCarDetails(CarDetails car);
}