package com.example.RentandDrive_Backend.service;
import com.example.RentandDrive_Backend.entity.Car;
import java.util.List;

public interface CarService {
     public List<Car> getCars();
     public Car addCar(Car car);
     public Car deleteCar(long id);
     public Car updateCar(Car car);
}
