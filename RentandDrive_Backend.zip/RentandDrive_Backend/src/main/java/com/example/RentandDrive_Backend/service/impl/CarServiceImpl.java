package com.example.RentandDrive_Backend.service.impl;

import java.util.List;

import com.example.RentandDrive_Backend.service.CarService;
import org.springframework.stereotype.Service;

import com.example.RentandDrive_Backend.entity.Car;
import com.example.RentandDrive_Backend.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class CarServiceImpl implements CarService {

	@Autowired
	private CarRepository carRepository;
	@Override
	public List<Car> getCars() {
		// TODO Auto-generated method stub
		return carRepository.findAll();
	}

	@Override
	public Car addCar(Car car) {
		carRepository.save(car);
		return car;
	}

	@Override
	public Car deleteCar(long id) {
		@SuppressWarnings("deprecation")
		Car item=carRepository.getById(id);
		carRepository.delete(item);
		return item;
	}

	@Override
	public Car updateCar(Car car) {
		//carRepository.save(car);
		return car;
	}

}
