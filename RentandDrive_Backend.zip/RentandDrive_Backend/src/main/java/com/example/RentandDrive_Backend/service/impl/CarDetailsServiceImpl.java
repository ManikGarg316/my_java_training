package com.example.RentandDrive_Backend.service.impl;
import java.util.List;

import com.example.RentandDrive_Backend.service.CarDetailsService;
import org.springframework.stereotype.Service;

import com.example.RentandDrive_Backend.entity.CarDetails;
import com.example.RentandDrive_Backend.repository.CarDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class CarDetailsServiceImpl implements CarDetailsService {

	@Autowired
	private CarDetailsRepository carRepository;
	@Override
	public List<CarDetails> getCarDetails(long carid) {
		// TODO Auto-generated method stub
		return carRepository.findBycarid(carid);
	}

	@Override
	public CarDetails addCarDetails(CarDetails car) {
		carRepository.save(car);
		return car;
	}

	@Override
	public CarDetails deleteCarDetails(long id) {
		@SuppressWarnings("deprecation")
		CarDetails item=carRepository.getById(id);
		carRepository.delete(item);
		return item;
	}

	@Override
	public CarDetails updateCarDetails(CarDetails car) {
		carRepository.save(car);
		return car;
	}

}
