package com.example.demo;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class BankPortalController 
{
	@Autowired
	private JdbcTemplate jt;
	
	
	@GetMapping("/dashboard")
	public String showDashboard()
	{
		return "dashboard";
	}
	
	@GetMapping("/register")
	public String showRegister()
	{
		return "register";
	}
	
	@GetMapping("/profile")
	public String showProfile() {
		return "profile";
	}
	
	@GetMapping("/chequebook")
	public String showCheckqueBookRequest() {
		return "chequebook";
	}
	
	@GetMapping("/loans")
	public String showLoanApplication()
	{
		return "loans";
	}
	
	@GetMapping("/cards")
	public String showCreditCards()
	{
		return "cards";
	}
	
	@GetMapping("/query")
	public String showQuery()
	{
		return "query";
	}
	
	@GetMapping("/suggestions")
	public String showSuggestion()
	{
		return "suggestions";
	}
	
	@GetMapping("/netbanking")
	public String showNetBanking()
	{
		return "netbanking";
	}
	
	@GetMapping("/transactions")
	public String showTransactions()
	{
		return "transactions";
	}
	
	@GetMapping("/editcontact")
	public String showEditContact()
	{
		return "editcontact";
	}
	
	/* Middleware to Backend */
	
//	@RequestMapping("/reg")
//	public String doRegistration(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
//	{
//		String a=req.getParameter("t1");
//		String b=req.getParameter("t2");
//		String c=req.getParameter("t3");
//		String d=req.getParameter("t4");
//		String e=req.getParameter("t5");
//		String f=req.getParameter("t6");
//		
//		String sql="insert into registration1 values(?,?,?,?,?,?)";
//		jt.update(sql,a,b,c,d,e,f);
//		System.out.println("row inserted");
//		return "success";
//		
//	}
	
	
//	@RequestMapping("/feed")
//	public String doFeedback(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
//	{
//		String a=req.getParameter("t7");
//		String b=req.getParameter("t8");
//		String c=req.getParameter("t9");
//		
//		String sql="insert into feedback values(?,?,?)";
//		jt.update(sql,a,b,c);
//		System.out.println("row inserted");
//		return "success";
//	}
	
//	@RequestMapping("/bk")
//	public String doBook(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
//	{
//		String a=req.getParameter("t10");
//		
//		String sql="insert into doctor values(?)";
//		jt.update(sql,a);
//		System.out.println("row inserted");
//		return "success";
//	}
	
//	@RequestMapping("/bk1")
//	public String doBook1(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
//	{
//		String a=req.getParameter("t11");
//		String b=req.getParameter("t12");
//		String c=req.getParameter("t13");
//		String d=req.getParameter("t14");
//		String e=req.getParameter("t15");
//		String f=req.getParameter("t16");
//		String g=req.getParameter("t17");
//		String h=req.getParameter("t18");
//
//		
//		String sql="insert into bed values(?,?,?,?,?,?,?,?)";
//		jt.update(sql,a,b,c,d,e,f,g,h);
//		System.out.println("row inserted");
//		return "success";
//	}
	
//	@RequestMapping("/bk2")
//	public String doBook2(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
//	{
//		String a=req.getParameter("t19");
//		String b=req.getParameter("t20");
//		String c=req.getParameter("t21");
//		String d=req.getParameter("t22");
//		String e=req.getParameter("t23");
//		String f=req.getParameter("t24");
//		String g=req.getParameter("t25");
//
//		
//		String sql="insert into ambulance values(?,?,?,?,?,?,?)";
//		jt.update(sql,a,b,c,d,e,f,g);
//		System.out.println("row inserted");
//		return "success";
//	}
//	
	
}
