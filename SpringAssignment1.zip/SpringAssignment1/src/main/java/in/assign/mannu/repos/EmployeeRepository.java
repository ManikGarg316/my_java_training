package in.assign.mannu.repos;
import org.springframework.data.jpa.repository.JpaRepository;
import in.assign.mannu.models.Employee;
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
}
