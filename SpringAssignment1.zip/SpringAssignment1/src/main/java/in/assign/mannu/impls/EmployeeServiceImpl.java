package in.assign.mannu.impls;
//import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.assign.mannu.models.Employee;
import in.assign.mannu.repos.EmployeeRepository;
import in.assign.mannu.services.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeRepository repo;
	
	@Transactional
	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		repo.save(emp);
	}

	@Override
	public void editEmployee(Employee emp, int empid) {
		// TODO Auto-generated method stub
		repo.deleteById(empid);
		repo.save(emp);
	}

	@Override
	public boolean deleteEmployee(int empid) {
		// TODO Auto-generated method stub
		repo.deleteById(empid);
		return true;
	}

	@Override
	public Employee getEmployeeById(int empid) {
		// TODO Auto-generated method stub
		Optional<Employee> temp = repo.findById(empid);
		try {
			return temp.get();
		} catch(Exception e) {
			return null;
		}
//		return null;
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return repo.findAll();
		
	}

}
