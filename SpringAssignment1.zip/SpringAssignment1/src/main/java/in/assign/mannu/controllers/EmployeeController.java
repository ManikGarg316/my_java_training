package in.assign.mannu.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import in.assign.mannu.models.Employee;
import in.assign.mannu.services.EmployeeService;


@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	@PostMapping("/addemp")
	public String saveEmployee(
			@ModelAttribute Employee emp,
			Model model)
	{
		service.addEmployee(emp);
		
		
//		model.addAttribute("message", msg);
		return "employee with emp id: " + emp.getEmpid() + "added";
	}
	
	@PostMapping("/deleteemp/{id}")
	public String deleteEmployee(
			@ModelAttribute Employee emp,
			Model model)
	{
		service.deleteEmployee(emp.getEmpid());
		
		
//		model.addAttribute("message", msg);
		return "employee with emp id: " + emp.getEmpid() + "added";
	}
}
