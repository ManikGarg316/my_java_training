package com.app.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.app.project.model.User;
import com.app.project.service.UserService;

@CrossOrigin(origins = "http://localhost:3000")
@Controller
public class EditController {
	
	@Autowired
	private UserService service;
	
	@PutMapping("/edit/{username}")
	public ResponseEntity<String> editUser(
			@RequestBody User user,
			@PathVariable String username)
	{
		user.setUsername(username);
		String msg = service.editUser(user, username);
//		
//		if(id!=null) {
//			String text = "User : "+ user.getName() +" , created with roles:"+user.getRoles();
//			boolean sent = emailUtil.send(user.getEmail(), "WELCOME TO USER!", text);
//			if(sent)
//				msg+=", Email also sent :)";
//			else 
//				msg+=", Email sending Failed :(";
//		}
//		
		ResponseEntity<String> resp=new ResponseEntity<String>(msg,HttpStatus.OK);
		return resp;
	}
	
//	@DeleteMapping("/delete/{username}")
//	public ResponseEntity<String> deleteUser(@PathVariable username){
//		
//	}
	
}
