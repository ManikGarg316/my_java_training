package com.app.project.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;

import com.app.project.model.Car;
import com.app.project.service.CarService;

@CrossOrigin(origins = "http://localhost:3000")
@Controller
public class CarsController {
	@Autowired(required=true)
	private CarService service;
	
//	@GetMapping("/cars")
//	public List<Car> getCars(@RequestParam(defaultValue = "empty") String fuel, @RequestParam(defaultValue = "empty") String seats)
//	{
//		return service.filterByOptionalSeatsAndOptionalFuel(Integer.parseInt(seats), fuel);
//	}
	
	@GetMapping("/cars/{carid}")
	public Optional<Car> getCars(@PathVariable String carid)
	{
		return service.findByCarNumber(carid);
	}
	
	@PostMapping("/cars/add")
	public String saveCar(@RequestBody Car car)
	{
		return service.addCar(car);
	}
	
	@DeleteMapping("cars/delete/{carnum}")
	public String deleteCar(@PathVariable String carnum) {
		return service.deleteCar(carnum);
	}
}
