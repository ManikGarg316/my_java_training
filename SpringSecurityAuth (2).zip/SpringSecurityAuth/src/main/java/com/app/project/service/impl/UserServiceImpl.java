package com.app.project.service.impl;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.project.model.User;
import com.app.project.service.UserService;

import com.app.project.repo.UserRepository;
@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private BCryptPasswordEncoder pwdEncoder;

	@Autowired
	private UserRepository repo;
	
	@Override
	public String addUser(User user) {
		// TODO Auto-generated method stub
		String pwd = user.getPassword();
		String encPwd = pwdEncoder.encode(pwd);
		user.setPassword(encPwd);

		// save password
		user = repo.save(user);
		return "User created successfully";
	}

	@Override
	public String editUser(User user, String username) {
		// TODO Auto-generated method stub
		Optional<User> userDB = repo.findById(username);
		if(userDB.isPresent()) {
			repo.delete(user);
		}
		repo.save(user);
		return "User edited successfully";
	}

	@Override
	public String deleteUser(String username) {
		// TODO Auto-generated method stub
		repo.deleteById(username);
		return "User deletion successful";
	}

	@Override
	public String loginUser(User user) {
		// TODO Auto-generated method stub
		String encPwd = pwdEncoder.encode(user.getPassword());
		user.setPassword(encPwd);
		Optional<User> userDB = repo.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		if(userDB.isPresent()) {
			return userDB.get().getUsername();
		}
		return "Username or password is wrong";
	}

}
