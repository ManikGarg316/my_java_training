package com.app.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.app.project.model.Car;

public interface CarService {
	public String addCar(Car car);
	public List<Car> getAllCars();
	public Optional<Car> findByCarNumber(String carNumber);
	public String deleteCar(String carNumber);
//	public List<Car> filterByOptionalSeatsAndOptionalFuel(Integer numOfSeats, String fuel);
}
