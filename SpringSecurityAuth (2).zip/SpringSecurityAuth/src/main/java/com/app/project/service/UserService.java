package com.app.project.service;

import org.springframework.stereotype.Service;

import com.app.project.model.User;

public interface UserService {
	public String addUser(User user);
	public String editUser(User user, String username);
	public String deleteUser(String username);
	public String loginUser(User user);
}
