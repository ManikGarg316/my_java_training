package com.app.project.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.project.model.Car;
import com.app.project.repo.CarRepository;
import com.app.project.service.CarService;
@Service
public class CarServiceImpl implements CarService{
	@Autowired
	private CarRepository repo;

	@Override
	public String addCar(Car car) {
		repo.save(car);
		return "Car saved in system successfully";
	}

	@Override
	public List<Car> getAllCars() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Optional<Car> findByCarNumber(String carNumber) {
		// TODO Auto-generated method stub
		return repo.findById(carNumber);
	}

	@Override
	public String deleteCar(String carNumber) {
		// TODO Auto-generated method stub
		repo.deleteById(carNumber);
		return "Car deleted successfully";
	}

//	@Override
//	public List<Car> filterByOptionalSeatsAndOptionalFuel(Integer numOfSeats, String fuel) {
//		// TODO Auto-generated method stub
//		if(numOfSeats == null && fuel == null) {
//			return repo.findAll();
//		}
//		else if(numOfSeats == null) {
//			return repo.findByFuel(fuel);
//		}
//		else if(fuel == null) {
//			return repo.findBySeats(numOfSeats);
//		}
//		else {
//			return repo.findBySeatsAndFuel(numOfSeats, fuel);
//		}
//	}

	
	
}
