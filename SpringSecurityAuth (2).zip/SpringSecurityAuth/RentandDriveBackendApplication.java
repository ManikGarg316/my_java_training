package com.example.RentandDrive_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentandDriveBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentandDriveBackendApplication.class, args);
	}

}
