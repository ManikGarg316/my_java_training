interface IProduct
{
Name:string;
Price:number;
Instock:boolean;
}

function getdata<T>(obj:T)
{
for(var property in obj)
{
console.log(`${property} : ${obj[property]}`);
}
}

getdata<IProduct>({Name:'Samsung TV',Price :35000,Instock:true});

getdata<IProduct>({Name:'Samsung Fridge',Price :45000,Instock:false});