console.log("My first program in typescript");
