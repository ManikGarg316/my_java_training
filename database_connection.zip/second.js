function getdata(obj) {
    for (var property in obj) {
        console.log("".concat(property, " : ").concat(obj[property]));
    }
}
getdata({ Name: 'Samsung TV', Price: 35000, Instock: true });
getdata({ Name: 'Samsung Fridge', Price: 45000, Instock: false });
