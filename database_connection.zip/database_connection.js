var mongoose = require("mongoose");
var con = mongoose.connect('mongodb://127.0.0.1:27017/hdfc');
console.log("connected");