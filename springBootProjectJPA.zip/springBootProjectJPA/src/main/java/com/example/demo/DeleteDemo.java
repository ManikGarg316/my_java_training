package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component("deletion")
public class DeleteDemo implements CommandLineRunner, Ordered{
	@Autowired
	private JdbcTemplate jt;
	
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		String x = "delete from hdfcemploy where empno=?";
		int count = jt.update(x, 101);
		System.out.println("row deleted: "+count);
	}

	@Override
	public int getOrder() {
		// TODO Auto-generated method stub
		return 3;
	}

}
