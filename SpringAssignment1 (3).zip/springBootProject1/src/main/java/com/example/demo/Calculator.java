package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

@Component("cal")
public class Calculator implements CommandLineRunner, Ordered{
	
	public int square(int a) {
		return a*a;
	}
	
	public int mult(int a, int b) {
		return a*b;
	}
	
	@Override
	public int getOrder() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("this is calculator");
	}

}
