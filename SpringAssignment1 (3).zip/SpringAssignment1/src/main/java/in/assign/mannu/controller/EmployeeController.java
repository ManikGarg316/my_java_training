package in.assign.mannu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import in.assign.mannu.model.Employee;
import in.assign.mannu.service.EmployeeService;


@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	@PostMapping("/addemp")
	public ResponseEntity<Employee> saveEmployee(
			@ModelAttribute Employee emp,
			Model model)
	{
//		service.addEmployee(emp);
		
		
//		model.addAttribute("message", msg);
//		return "employee with emp id: " + emp.getEmpid() + "added";
		ResponseEntity<Employee> resp=new ResponseEntity<Employee>(emp,HttpStatus.OK);
		return resp;
	}
	
	@DeleteMapping("/deleteemp/{id}")
	public String deleteEmployee(@PathVariable Integer id)
	{
		service.deleteEmployee(id);
		
		
//		model.addAttribute("message", msg);
		return "employee with emp id: " + id + "added";
	}
}
