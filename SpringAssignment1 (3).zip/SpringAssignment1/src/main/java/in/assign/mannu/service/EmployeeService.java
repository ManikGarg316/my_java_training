package in.assign.mannu.service;
import java.util.*;

import in.assign.mannu.model.Employee;

public interface EmployeeService {
	public void addEmployee(Employee emp);
	public void editEmployee(Employee emp, int empid);
	public boolean deleteEmployee(int empid);
	public Employee getEmployeeById(int empid);
	public List<Employee> getAllEmployee();
}
