package in.assign.mannu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAssignment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
